package ntu.mdpteam5;

import android.content.ClipData;
import android.content.ClipDescription;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
//import android.support.v4.app.FragmentTransaction;
//import android.support.v7.app.AlertDialog;
//import android.support.v7.app.AppCompatActivity;
import android.view.DragEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.util.Log;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import java.util.ArrayList;

import ntu.mdpteam5.bluetooth.BluetoothChatFragment;
import ntu.mdpteam5.model.HexBin;
import ntu.mdpteam5.model.IDblock;
import ntu.mdpteam5.model.Map;
import ntu.mdpteam5.model.Position;
import ntu.mdpteam5.model.Robot;
import ntu.mdpteam5.model.WayPoint;

public class MainActivity extends AppCompatActivity {
    GridLayout base_layout;
    BluetoothChatFragment fragment;
    MenuItem menu_show_bluetooth_chat;


    TextView tv_status;
    Button btn_forward;
    Button btn_left;
    Button btn_right;
    Button btn_obs1;
    Button btn_obs2;
    Button btn_obs3;
    Button btn_obs4;
    Button btn_obs5;
    Button btn_robot;
    Button btn_start;
    Button btn_Cam;

    String status = "Idle";

    private android.widget.RelativeLayout.LayoutParams layoutParams;
    String msg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //initialize all the buttons
        tv_status = (TextView) findViewById(R.id.tv_status);
        btn_forward = (Button) findViewById(R.id.btn_forward);
        btn_left= (Button) findViewById(R.id.btn_left);
        btn_right= (Button) findViewById(R.id.btn_right);
        btn_obs1= (Button) findViewById(R.id.btn_obs1);
        btn_obs2= (Button) findViewById(R.id.btn_obs2);
        btn_obs3= (Button) findViewById(R.id.btn_obs3);
        btn_obs4= (Button) findViewById(R.id.btn_obs4);
        btn_obs5= (Button) findViewById(R.id.btn_obs5);
        btn_robot= (Button) findViewById(R.id.btn_robot);
        btn_start= (Button) findViewById(R.id.btn_start);
        btn_Cam= (Button) findViewById(R.id.btn_Cam);
        base_layout = (GridLayout) findViewById(R.id.base_layout);

        //initialize the bluetooth service component
        if (savedInstanceState == null) {
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            fragment = new BluetoothChatFragment();
            transaction.replace(R.id.sample_content_fragment, fragment);
            transaction.commit();
        }

        //initialize default status "idle"
        updateStatus(status);

        //initialize listener for all the buttons
        setBtnListener();



        //initialize the grid
        loadGrid();
    }

    //method to update the label textview
    public void updateStatus(String status){
        this.status = status;
        tv_status.setText(status);
    }

    //method to set all the event for buttons
    private void setBtnListener(){
        btn_start.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                outgoingMessage("Start");

                updateStatus("START");
            }
        });

        btn_Cam.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                outgoingMessage("StarDetec");

                updateStatus("START DETECTION");
            }
        });

        btn_forward.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                //check if robot is out of bounds
                if(!Robot.getInstance().isOutOfBounds()) {
                    Robot.getInstance().moveForward(10);
                    outgoingMessage("W", 1);
                    loadGrid();
                }
            }
        });
        btn_left.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Robot.getInstance().rotateLeft();
                outgoingMessage("A", 1);
                loadGrid();
            }
        });
        btn_right.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Robot.getInstance().rotateRight();
                outgoingMessage("D", 1);
                loadGrid();
            }
        });

        btn_obs1.setOnTouchListener(obs1TouchListener);
        btn_obs2.setOnTouchListener(obs2TouchListener);
        btn_obs3.setOnTouchListener(obs3TouchListener);
        btn_obs4.setOnTouchListener(obs4TouchListener);
        btn_obs5.setOnTouchListener(obs5TouchListener);
        btn_robot.setOnTouchListener(rbtTouchListener);
        base_layout.setOnDragListener(dragListener);


    }

    View.OnLongClickListener longClickListener = (new View.OnLongClickListener() {
        @Override
        public boolean onLongClick(View v) {
            ClipData.Item item = new ClipData.Item((CharSequence)v.getTag());
            String[] mimeTypes = {ClipDescription.MIMETYPE_TEXT_PLAIN};

            ClipData dragData = new ClipData(v.getTag().toString(),mimeTypes, item);
            View.DragShadowBuilder myShadow = new View.DragShadowBuilder(btn_obs1);

            v.startDrag(dragData,myShadow,null,0);
            return true;
        }
    });


    View.OnTouchListener obs1TouchListener = (new View.OnTouchListener() {
        @Override
        public boolean onTouch(View v, MotionEvent event) {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                ClipData data = ClipData.newPlainText("obs1", "");
                View.DragShadowBuilder shadowBuilder = new View.DragShadowBuilder(v);

                btn_obs1.startDrag(data, shadowBuilder, v, 0);
                //btn_obs1.setVisibility(View.INVISIBLE);
                return true;
            } else {
                return false;
            }
        }
    });

    View.OnTouchListener obs2TouchListener = (new View.OnTouchListener() {
        @Override
        public boolean onTouch(View v, MotionEvent event) {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                ClipData data = ClipData.newPlainText("obs2", "");
                View.DragShadowBuilder shadowBuilder = new View.DragShadowBuilder(v);

                btn_obs1.startDrag(data, shadowBuilder, v, 0);
                //btn_obs1.setVisibility(View.INVISIBLE);
                return true;
            } else {
                return false;
            }
        }
    });

    View.OnTouchListener obs3TouchListener = (new View.OnTouchListener() {
        @Override
        public boolean onTouch(View v, MotionEvent event) {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                ClipData data = ClipData.newPlainText("obs3", "");
                View.DragShadowBuilder shadowBuilder = new View.DragShadowBuilder(v);

                btn_obs1.startDrag(data, shadowBuilder, v, 0);
                //btn_obs1.setVisibility(View.INVISIBLE);
                return true;
            } else {
                return false;
            }
        }
    });

    View.OnTouchListener obs4TouchListener = (new View.OnTouchListener() {
        @Override
        public boolean onTouch(View v, MotionEvent event) {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                ClipData data = ClipData.newPlainText("obs4", "");
                View.DragShadowBuilder shadowBuilder = new View.DragShadowBuilder(v);

                btn_obs1.startDrag(data, shadowBuilder, v, 0);
                //btn_obs1.setVisibility(View.INVISIBLE);
                return true;
            } else {
                return false;
            }
        }
    });

    View.OnTouchListener obs5TouchListener = (new View.OnTouchListener() {
        @Override
        public boolean onTouch(View v, MotionEvent event) {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                ClipData data = ClipData.newPlainText("obs5", "");
                View.DragShadowBuilder shadowBuilder = new View.DragShadowBuilder(v);

                btn_obs1.startDrag(data, shadowBuilder, v, 0);
                //btn_obs1.setVisibility(View.INVISIBLE);
                return true;
            } else {
                return false;
            }
        }
    });

    View.OnTouchListener rbtTouchListener = (new View.OnTouchListener() {
        @Override
        public boolean onTouch(View v, MotionEvent event) {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                ClipData data = ClipData.newPlainText("rbt", "");
                View.DragShadowBuilder shadowBuilder = new View.DragShadowBuilder(v);

                btn_robot.startDrag(data, shadowBuilder, v, 0);
                //btn_robot.setVisibility(View.INVISIBLE);
                return true;
            } else {
                return false;
            }
        }
    });

    View.OnDragListener dragListener = (new View.OnDragListener() {
        @Override
        public boolean onDrag(View v, DragEvent event) {

            switch(event.getAction()) {
                case DragEvent.ACTION_DRAG_STARTED:
                    return true;

                case DragEvent.ACTION_DRAG_ENTERED:
                    return true;

                case DragEvent.ACTION_DRAG_EXITED :
                    return true;

                case DragEvent.ACTION_DRAG_LOCATION  :
                    return true;

                case DragEvent.ACTION_DRAG_ENDED   :
                    return true;
                case DragEvent.ACTION_DROP:

                    String btn = (String) event.getClipDescription().getLabel();
                    if(btn.contains("obs") == true) {
                            float X;
                            float Y;

                            float selectedX;
                            float selectedY;
                            float w = base_layout.getWidth() - 2 * 50;
                            float h = base_layout.getHeight() - 50;
                            float cellWidth = w / 20f;
                            float cellHeight = h / 20f;

                            float paddingX = 36;
                            float paddingY = 0;
                            int lastX;
                            int lastY;

                            int posX;
                            int posY;
                            X = (int) event.getX();

                            Y = (int) event.getY();
                            selectedX = X - paddingX;
                            selectedY = Y - paddingY;
                            posX = (int) (selectedX / cellWidth);
                            posY = 19 - (int) (selectedY / cellHeight);
                            lastX = posX;
                            lastY = posY;
                            Position s = new Position(lastX, lastY);

                            String IDstring = "";

                            if (btn.contains("obs1")== true)
                            {
                                IDstring = "1";
                            }
                            else if (btn.contains("obs2")== true)
                            {
                                IDstring = "2";
                            }
                            else if (btn.contains("obs3")== true)
                            {
                                IDstring = "3";
                            }
                            else if (btn.contains("obs4")== true)
                            {
                                IDstring = "4";
                            }
                            else if (btn.contains("obs5")== true)
                            {
                                IDstring = "5";
                            }

                            float direction = 0;

                            IDblock input = new IDblock(IDstring, direction, s);
                            Map.getInstance().addNumberedBlocks(input);
                            if (posX<0 || posY<0 || posX>19 || posY>19)
                            {
                                outgoingMessage("SubObs:"+ IDstring);

                                updateStatus("SubObs,"+ IDstring);
                            }
                            else
                            {
                            outgoingMessage("ADDOBS:"+IDstring+ ","+(int)posX+","+(int)posY + ",N", 0);
                            updateStatus("Obs ID: "+IDstring+ ","+(int)posX+","+(int)posY + ",N");
                            }
                            //IDblock.getInstance().setPosition(s);
                            //Make a prompt here to confirm
                            loadGrid();
                            ;
                            // Do nothing
                            return true;
                    }
                    else if(btn.contains("rbt") == true) {
                            float X;
                            float Y;

                            float selectedX;
                            float selectedY;
                            float w = base_layout.getWidth() - 2 * 50;
                            float h = base_layout.getHeight() - 50;
                            float cellWidth = w / 20f;
                            float cellHeight = h / 20f;

                            float paddingX = 36;
                            float paddingY = 0;
                            int lastX;
                            int lastY;
                            String toastText;

                            int posX;
                            int posY;
                            X = (int) event.getX();
                            ;
                            Y = (int) event.getY();
                            selectedX = X - paddingX;
                            selectedY = Y - paddingY;
                            posX = (int) (selectedX / cellWidth);
                            posY = 19 - (int) (selectedY / cellHeight);

                            Robot r = Robot.getInstance();
                            r.setPosX(posX);
                            r.setPosY(posY);
                            r.setDirection("N");


                            outgoingMessage("ROBOT:"+(int)posX+","+(int)posY+","+"N", 0);

                            updateStatus("Robot: "+(int)posX+","+(int)posY+"N");

                            //IDblock.getInstance().setPosition(s);
                            //Make a prompt here to confirm
                            loadGrid();
                            ;
                            // Do nothing
                            return true;
                    }
                default:
                    break;
            }
            return true;
        }
    });
    //initalize all the menu item button
    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        super.onPrepareOptionsMenu(menu);
        menu_show_bluetooth_chat = menu.findItem(R.id.action_show_bluetooth_chat);
        return true;
    }

    //load/reload the Grid View into the page
    private void loadGrid(){
        MapCanvas mCustomDrawableView = new MapCanvas(this);
        base_layout.removeAllViews();
        base_layout.addView(mCustomDrawableView);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    //this is the event when menu item is clicked
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();


        if (id == R.id.action_show_bluetooth_chat) {
            boolean checked = item.isChecked();
            item.setChecked(!checked);
            if(fragment!=null){
                fragment.showChat(!checked);
            }
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    //this method opens up a dialog to save input string on the phone
    //index is the key of the string.
    //eg string 1 is stored in 'string1', string 2 in 'string2'
    private void setConfiguredString(final int index){
        final EditText txtField = new EditText(this);
        SharedPreferences prefs = getSharedPreferences(String.valueOf(R.string.app_name), MODE_PRIVATE);
        String retrievedText = prefs.getString("string"+index, null);
        if (retrievedText != null) {
            txtField.setText(retrievedText);
        }

        new AlertDialog.Builder(this)
                .setTitle("Configure String "+index)
                .setView(txtField)
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        String input = txtField.getText().toString();
                        SharedPreferences.Editor editor = getSharedPreferences(String.valueOf(R.string.app_name), MODE_PRIVATE).edit();
                        editor.putString("string"+index, input);
                        editor.apply();
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                    }
                })
                .show();
    }

    private void displayDataStrings(){

        // create an alert builder
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("MDF + Image String");

        // set the custom layout
        final View customLayout = getLayoutInflater().inflate(R.layout.data_strings, null);
        builder.setView(customLayout);

        // add a button
        builder.setPositiveButton("CLOSE", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // send data from the AlertDialog to the Activity
                dialog.dismiss();
            }
        });

        // set the custom dialog components - text, image and button
        EditText text_mdf1 = (EditText) customLayout.findViewById(R.id.textbox_mdf1);
        String explored = HexBin.binToHex(Map.getInstance().getBinaryExplored());
        text_mdf1.setText(explored);

        EditText text_mdf2 = (EditText) customLayout.findViewById(R.id.textbox_mdf2);
        String obstacles = HexBin.binToHex(Map.getInstance().getBinaryExploredObstacle());
        //obstacles = obstacles + ";" + Map.getInstance().getObstacleStringFromAlgo();
        text_mdf2.setText(obstacles);

        EditText text_imgreg = (EditText) customLayout.findViewById(R.id.textbox_imgreg);
        String imgreg = "{";
        ArrayList<IDblock> numberedBlocks = Map.getInstance().getNumberedBlocks();
        for(IDblock blk : numberedBlocks){
            imgreg += String.format("(%s, %d, %d)", blk.getID(), blk.getPosition().getPosX(), blk.getPosition().getPosY());
            imgreg += ", ";
        }
        if(imgreg.length()>2)imgreg = imgreg.substring(0, imgreg.length()-2);
        imgreg += "}";
        text_imgreg.setText(imgreg);

        // create and show the alert dialog
        AlertDialog dialog = builder.create();
        dialog.show();
    }


    //this is to uncheck all the checkable menuitem
//    private void clearAllEditableCheckbox(){
//        menu_set_robot_position.setChecked(false);
//        menu_set_waypoint.setChecked(false);
//        menu_enable_swipe_input.setChecked(false);
//    }

    public static final String STATUS_EX_DESC = "Moving (Exploring)";
    public static final String STATUS_FP_DESC = "Moving (Fastest Path)";
    public static final String STATUS_TERMINATE_DESC = "Terminated";

    //method is ran when new message comes in
    public void incomingMessage(String readMsg) {
        //update map

        final Robot r = Robot.getInstance();

        if(readMsg.length()>0){
            menu_show_bluetooth_chat.setChecked(true);
            fragment.showChat(true);
            String message[];
            // - delimiter for imgReg, : delimiter for everythig else
            if(readMsg.contains(":")) {
                message = readMsg.split(":");
            }else{
                message = readMsg.split("-");
            }

            if (message[0].equals("GRID")) { //receive mapDescriptor from Algo
                Map.getInstance().setMapJson(message[1]);
//                if (menu_auto_update_map != null && menu_auto_update_map.isChecked()) {
                    loadGrid();
//                }
            }

            else if (message[0].equals("DATA")) { //receive full data string (P1, P2, robot pos) from Algo
                String data[] = message[1].split(",");

                Map.getInstance().setMap(data[0], "", data[1]);

                r.setPosX(Float.parseFloat(data[2]));
                r.setPosY(Float.parseFloat(data[3]));
                r.setDirection(data[4]);

//                if (menu_auto_update_map != null && menu_auto_update_map.isChecked()) {
                    loadGrid();
//                }
            }

            else if (message[0].equals("TARGET")) { //receive numbered block
                String data[] = message[1].split(","); //x, y, id, direction
                    float direction = 45;
//                    if (data[3].contains("N") == true)
//                    {
//                        direction=0;
//                    }
//                    else if (data[3].contains("E") == true)
//                    {
//                        direction=90;
//                    }
//                    else if (data[3].contains("S") == true)
//                    {
//                        direction=180;
//                    }
//                    else if (data[3].contains("W") == true)
//                    {
//                        direction=270;
//                    }

                    ArrayList<IDblock> numberedBlocks = Map.getInstance().getNumberedBlocks();
//                    int x = 0;
//                    int y = 0;

                    String id = data[0];
                    String imageid = data[1];

                    for(IDblock block:numberedBlocks)
                    {
                        String getid = block.getID();
                        if (data[0].contains(block.getID()))
                        {
                            block.setimageid(imageid);
                            break;
                        }
                    }
                    updateStatus("Found ImageID: "+ imageid);
//                    IDblock input = new IDblock(data[0], direction, Integer.parseInt(data[1]), Integer.parseInt(data[2]));
//                    Map.getInstance().addNumberedBlocks(input);
//                    if (Integer.parseInt(data[1])<0 || Integer.parseInt(data[2])<0 || Integer.parseInt(data[1])>19 || Integer.parseInt(data[2])>19)
//                    {
//                        outgoingMessage("SubObs,"+ data[0]);
//
//                        updateStatus("SubObs,"+ data[0]);
//                    }
//                    else
//                    {
//                        outgoingMessage("AddObs,"+data[0]+ ","+(int)Integer.parseInt(data[1])+","+(int)Integer.parseInt(data[2]) + ",N", 0);
//                        updateStatus("Obs ID: "+data[0]+ ","+(int)Integer.parseInt(data[1])+","+(int)Integer.parseInt(data[2]) + ",N");
//                    }
//                    if (menu_auto_update_map != null && menu_auto_update_map.isChecked()) {
                        loadGrid();
//                    }
                }


            else if (message[0].equals("ROBOT")) { //receive robot position
                String posAndDirect[] = message[1].split(",");
                r.setPosX(Float.parseFloat(posAndDirect[0]));
                r.setPosY(Float.parseFloat(posAndDirect[1]));
                r.setDirection(posAndDirect[2]);

//                if (menu_auto_update_map != null && menu_auto_update_map.isChecked()) {
                    loadGrid();
//                }
            }

            else if(message[0].equals("S")){
                if (message[1].equals("F")) {
                    Robot.getInstance().moveForward(10);
                    updateStatus("Moving Forward");
                    loadGrid();
                }
                if (message[1].equals("TR")) {
                    Robot.getInstance().rotateRight();
                    updateStatus("Turning Right");
                    loadGrid();
                }
                if (message[1].equals("TL")) {

                    Robot.getInstance().rotateLeft();
                    updateStatus("Turning Left");
                    loadGrid();
                }
//                if (message[1].equals("FP")) {
//                    updateStatus("Fastest Path");
//                }
//                if (message[1].equals("EX")) {
//                    updateStatus("Exploration");
//                }
//                if (message[1].equals("DONE")) {
//                    updateStatus("Done!");
//                }
            }
            else if(message[0].trim().equals("Y")){ //harmonize with algo
                updateStatus("Moving");
            }
            else if(message[0].trim().equals("F")){ //harmonize with algo
                updateStatus("Done!");
            }
            else {
                updateStatus("Invalid Message");
                }
            }
    }


    //method to send out message to rpi thru bluetooth -kept for backward compatibility
    public boolean outgoingMessage(String sendMsg) {
        return fragment.sendMsg(sendMsg);
    }
    public boolean outgoingMessage(String sendMsg, int destination) {
        //add delimiters
        // 0=algo/tcp, 1=ardu/serial
        if(destination == 0){
            sendMsg = sendMsg;
        }else if(destination == 1){
            sendMsg = sendMsg;
        }
        return fragment.sendMsg(sendMsg);
    }
    //clear waypoint
    private void removeWaypoint(){
        WayPoint.getInstance().setPosition(null);
        loadGrid();
    }

    //swipe gesture input
    public void onSwipeTop() {

        //check if robot is out of bounds
        if(!Robot.getInstance().rotateToNorth()){
            if(!Robot.getInstance().isOutOfBounds()) {
                outgoingMessage("W", 1);
                //getack
                Robot.getInstance().moveForward(10);
            }
        }
        else{
            Integer count = Robot.getInstance().getCount();
            sendMsgOnSwipe(count);
            //getack
            Robot.getInstance().rotateRobotToNorth();
        }
        loadGrid();
    }

    public void onSwipeLeft() {
        if(!Robot.getInstance().rotateToWest()){
            if(!Robot.getInstance().isOutOfBounds()) {
                outgoingMessage("W", 1);
                //getack
                Robot.getInstance().moveForward(10);
            }
        }
        else{
            Integer count = Robot.getInstance().getCount();
            sendMsgOnSwipe(count);
            //getack
            Robot.getInstance().rotateRobotToWest();
        }

        loadGrid();
    }

    public void onSwipeRight() {
        if(!Robot.getInstance().rotateToEast()){
            if(!Robot.getInstance().isOutOfBounds()) {
                outgoingMessage("W", 1);
                //getack
                Robot.getInstance().moveForward(10);
            }
        }
        else{
            Integer count = Robot.getInstance().getCount();
            sendMsgOnSwipe(count);
            //getack
            Robot.getInstance().rotateRobotToEast();
        }
        loadGrid();
    }

    public void onSwipeBottom() {
        if(!Robot.getInstance().rotateToSouth()){
            if(!Robot.getInstance().isOutOfBounds()) {

                outgoingMessage("W", 1);
                //getack
                Robot.getInstance().moveForward(10);
            }
        }
        else{
            Integer count = Robot.getInstance().getCount();
            sendMsgOnSwipe(count);
            //getack
            Robot.getInstance().rotateRobotToSouth();
        }
        loadGrid();
    }

    public void sendMsgOnSwipe(Integer count){

        if(count==1){
            outgoingMessage("D", 1);
        }
        if(count==2){
            outgoingMessage("D", 1);
            outgoingMessage("D", 1);
        }
        if(count==-1){
            outgoingMessage("A", 1);
        }
    }

    @Override
    protected void onStop() {
        // call the superclass method first
        super.onStop();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

}


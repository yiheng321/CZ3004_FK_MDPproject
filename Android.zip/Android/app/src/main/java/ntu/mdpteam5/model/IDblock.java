package ntu.mdpteam5.model;

public class IDblock {
	private String id = "";
	private String imageid = "";
	private Position position = null;
	public int count;
	private float direction = 0;

	public IDblock(String blockID, float direction, Position pos){
		this.position = pos;
		this.id = blockID;
		this.direction = direction;
	}

	public IDblock(String blockID, float direction, Position pos,String imageid){
		this.position = pos;
		this.id = blockID;
		this.imageid = imageid;
		this.direction = direction;
	}

	public IDblock(String blockID, float direction, int posX, int posY){
		this.position = new Position(posX, posY);
		this.id = blockID;
		this.direction = direction;
	}


	public String getID() { return id; }
	public String getimageid() { return imageid; }
	public void setimageid(String imageid) { this.imageid=imageid; }
	public float getDirection() { return direction; }
	public Position getPosition() {
		return position;
	}
	public void setPosition(Position position) {
		this.position = position;
	}
	public void setDirection(float direction) {
		this.direction = direction;
	}


}

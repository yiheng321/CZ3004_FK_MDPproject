package ntu.mdpteam5.model;

public class WayPoint {
	public static WayPoint obs=null;
	private Position position=null;
	//private Position position=new Position(1,10);
	public static WayPoint getInstance(){
		if(obs==null){
			obs= new WayPoint();
		}
		return obs;
	}

	public Position getPosition() {
		return position;
	}
	public void setPosition(Position position) {
		this.position = position;
	}

}
